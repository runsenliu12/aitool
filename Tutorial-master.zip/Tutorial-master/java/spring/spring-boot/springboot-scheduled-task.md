### SpringBoot实现定时任务的4中方式
* 使用Timer
* 使用ScheduledExecutorService
* 使用Spring Task
  * 简单的定时任务
  * 多线程执行
  * 执行时间的配置
  * cron表达式配置
* 整合Quartz