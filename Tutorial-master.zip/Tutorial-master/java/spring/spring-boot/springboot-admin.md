Spring Boot Admin 用于监控基于 Spring Boot 的应用，它是在 Spring Boot Actuator 的基础上提供简洁的可视化 WEB UI。
Spring Boot Admin 是一个管理和监控Spring Boot 应用程序的开源软件，它针对springboot的actuator接口进行UI美化封装。
Spring Boot Admin 提供了很多功能，如显示 name、id 和 version，显示在线状态，Loggers 的日志级别管理，Threads 线程管理，Environment 管理等。
在 Spring Cloud 中基于 Eureka 的 Spring Boot Admin 的搭建
在 Spring Cloud 中基于 Nacos 的 Spring Boot Admin 的搭建