```
{
    "editor.renderWhitespace": true,
    "editor.tabSize":4,
    "editor.folding": true,
    "diffEditor.ignoreTrimWhitespace": true,
    "files.trimTrailingWhitespace": true,
    "editor.insertSpaces": true,
    "update.channel": "none",
    "vsicons.dontShowNewVersionMessage": true,
    "spell.StopAsking": true
}
```
* vscode相同内容多选，同时修改: 先选中所要修改的内容，然后按 `ctrl + alt + l`，接着进行修改，修改完后保存，再次按`ctrl + alt + l`释放操作