* [Chrome好用的插件](http://note.youdao.com/noteshare?id=530c5fcc0dfba1feadf26748cce65666&sub=wcp1583414597450563)
* 浏览器URL中输入`data:text/html, <html contenteditable>`，可以当作记事本来使用
