* DB连接工具
    * DBeaver Community https://dbeaver.io/
* Terminal
    * Linux系统下使用Terminators
    * MobaXterm https://mobaxterm.mobatek.net/
* 搜索
    * magi.com AI智能搜索
* 框架
    * Ant Design Pro前端中后台开箱即用的框架 https://pro.ant.design/
    * Liferay 功能丰富的CMS系统
* 代码行统计工具
  * cloc.exe windows中cmd使用cloc.exe folderPath/
  * IDEA plugin statistic
* Java诊断工具
  *  阿里JAVA诊断工具Arthas
* S3
  * Minio是GlusterFS创始人之一Anand Babu Periasamy发布新的开源项目。Minio兼容Amason的S3分布式对象存储项目，采用Golang实现，客户端支持Java,Python,Javacript, Golang语言。Minio可以做为云存储的解决方案用来保存海量的图片，视频，文档。由于采用Golang实现，服务端可以工作在Windows,Linux, OS X和FreeBSD上。
* Aliyun
  * Tablestore 表格存储（集存储和搜索于一体，无需单独构建ES）
      * Wide Column： 列存储
      * Timeline模型：主要用于消息数据，使用于IM, Feed流和物联网设备
      * Timestream模型：适用于时序数据、时空数据
      * Grid模型：适用于科学大数据的存储和查询场景