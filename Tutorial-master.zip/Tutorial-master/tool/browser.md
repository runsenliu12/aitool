* [Chrome好用的插件](http://note.youdao.com/noteshare?id=530c5fcc0dfba1feadf26748cce65666&sub=wcp1583414597450563)
* 浏览器URL中输入data:text/html, <html contenteditable>，可以当作记事本来使用
* 主页推荐 https://a.maorx.cn/ 可添加多个搜索引擎，同时添加标签，可在不同设备同步，火狐需要安装New Tab Homepage来实现打开“新标签页”时显示的是homepage